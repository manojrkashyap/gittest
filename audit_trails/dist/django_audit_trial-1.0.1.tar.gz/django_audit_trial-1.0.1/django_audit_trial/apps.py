from django.apps import AppConfig


class DjangoAuditTrailConfig(AppConfig):
    name = 'django_audit_trail'
    verbose_name = "Django Audit Trails"
